# History

## 0.2.0
### Fixed
- Bug fixed in `length` subpackage for inches-to-feet conversion.
### Deprecated
- Removed Python 2.7 support.

## 0.1.0
### Added
- First release on PyPI.
